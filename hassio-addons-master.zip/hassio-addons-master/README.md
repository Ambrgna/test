# kdw2060 Home Assistant add-on repository

This is a repository you can add as source in Home Assitant's add-on store.
