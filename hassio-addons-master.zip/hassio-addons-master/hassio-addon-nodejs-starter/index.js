var express = require('express');
var app = express();

console.log('Hello World from starter project');