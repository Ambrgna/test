# Node.js starter project for Hass.io addons

Very basic project just to demonstrate te necessary config of the .json and docker files

